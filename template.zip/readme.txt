JUST A GREEK VEHICLE TEXTURE

JUST A TEXTURE FOR THE ORIGINAL MODEL: https://www.lcpdfr.com/downloads/gta5mods/vehiclemodels/37169-unmarked-act-police-road-policing-audi-avant-non-els-fivem-ready/

INSTALLATION:
1. DOWNLOAD THE ORIGINAL FILES FROM FOZZY (https://www.lcpdfr.com/downloads/gta5mods/vehiclemodels/37169-unmarked-act-police-road-policing-audi-avant-non-els-fivem-ready/)
2. RENAME THE template.png to ACTPOLAUDI_sign_1.png and template1.png to ACTPOLAUDI_sign_2.png
3. OPEN THE ACTRPavantum.ytd IN OPEN IV AND REPLACE THE FILE NAMED ACTPOLAUDI_sign_1 WITH THE FIRST ONE YOU RENAMED!
4. OPEN THE ACTRPavantum.ytd IN OPEN IV AND DRAG AND DROP THE FILE ACTPOLAUDI_sign_2.png INTO THE FILES INSIDE THE YTD!
5. THEN REPLACE THE ACTRPavantum.ytd FROM OPEN IV TO YOUR INSTALLATION/ RESOURCES FOLDER IN ORDER TO MAKE THE TEXTURE APPEAR!

RULES WHEN USING MY LIVERY:
1. YOU SHOULD NOT TAKE CREDIT OR RERELEASE MY LIVERY
2. YOU SHOULD NOT MAKE MONEY USING MY LIVERY
3. YOU MUST RESPECT THE TOS IN THE ORIGINAL FILES

Base Model - RAZ3R
Message Board - Raz3r
ACT Police Gear and ALPR - 1Kachy, textured by myself
Trunk Gear - GTA 5 Props retextured by myself
Other lights - Cj24 and Yacobe
Putting it all together - SGT Fozzy
ME - I made this texture 

LIVERY MADE BY ME (Fronx#0427)
IF YOU WANT SOMETHING JUST CONTACT ME (Fronx#0427) OR JOIN MY DISCORD https://discord.gg/vj2fvqYJv2

