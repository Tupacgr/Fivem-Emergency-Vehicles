JUST A GREEK VEHICLE TEXTURE

JUST A TEXTURE FOR THE ORIGINAL MODEL: https://www.lcpdfr.com/downloads/gta5mods/vehiclemodels/38391-act-police-unmarked-kia-stinger-non-els-fivem-ready/

INSTALLATION:
1. DOWNLOAD THE ORIGINAL FILES FROM FOZZY (https://www.lcpdfr.com/downloads/gta5mods/vehiclemodels/38391-act-police-unmarked-kia-stinger-non-els-fivem-ready/)
2. RENAME THE templatesting.png to ACTPOLSTING_sign_1.png and templatesting1.png to ACTPOLSTING_sign_2.png
3. OPEN THE ACTPOLstinger.ytd IN OPEN IV AND REPLACE THE FILE NAMED ACTPOLSTING_sign_1 WITH THE FIRST ONE YOU RENAMED!
4. OPEN THE ACTPOLstinger.ytd IN OPEN IV AND DRAG AND DROP THE FILE ACTPOLAUDI_sign_2.png INTO THE FILES INSIDE THE YTD TO ADD IT!
5. THEN REPLACE THE ACTPOLstinger.ytd FROM OPEN IV TO YOUR INSTALLATION/ RESOURCES FOLDER IN ORDER TO MAKE THE TEXTURE APPEAR!

RULES WHEN USING MY LIVERY:
1. YOU SHOULD NOT TAKE CREDIT OR RERELEASE MY LIVERY
2. YOU SHOULD NOT MAKE MONEY USING MY LIVERY
3. YOU MUST RESPECT THE TOS IN THE ORIGINAL FILES

Base Model - Mr ChocoTaco
Light Modules - Krul
Code3 Chase Mounts - JustScott
Boot gear - GTA 5 props retextured by Fozzy
Interior Gear - Raz3r, Bulldog designs, Jakub and 0taku
Major fixes to base model, various retextures, redirt mapped and templated and putting it all together - Fozzy
ME - I made this texture 

LIVERY MADE BY ME (Fronx#0427)
IF YOU WANT SOMETHING JUST CONTACT ME (Fronx#0427) OR JOIN MY DISCORD https://discord.gg/YHfkCUmxzE

